import React from 'react'
import ShoppingBagIcon from '@mui/icons-material/ShoppingBag';
import FavoriteIcon from '@mui/icons-material/Favorite';
import HomeIcon from '@mui/icons-material/Home';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import InsertInvitationIcon from '@mui/icons-material/InsertInvitation';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from "react-router-dom";
import { useMediaQuery, Drawer, Divider } from "@mui/material";
import AddReactionIcon from '@mui/icons-material/AddReaction';
import EventIcon from '@mui/icons-material/Event';

export const menu = [
  { title: "Orders", icon: <ShoppingBagIcon /> },
  { title: "Favorites", icon: <FavoriteIcon /> },
  { title: "Address", icon: <AddReactionIcon /> },
  { title: "Payments", icon: <AccountBalanceWalletIcon /> },
  { title: "Notification", icon: <NotificationsActiveIcon /> },
  { title: "Events", icon: <EventIcon /> },
  { title: "Logout", icon: <LogoutIcon /> }
];

export const ProfileNavigation = ({ open, handleClose }) => {
    const isSmallScreen = useMediaQuery("(min-width:600px)");
    const navigate = useNavigate();  

    const handleNavigate = (item) => {
      if (item.title === "Logout") {
        dispatch(logout());
        navigate("/")
      } else {
        navigate(`/my-profile/${item.title.toLowerCase()}`);
      }
    }; 
  return (
    <div>
      <Drawer
        variant={isSmallScreen ? "temporary" : "permanent"}
        onClose={handleClose}
        open={open}
        anchor="left"
        sx={{ zIndex: 1,position: "sticky" }}
      >
        <div className='w-[50vw] lg:w-[20vw] h-[100vh] flex flex-col
        justify-center text-xl gap-8 pt-16 '>
          {menu.map((item, i) => (
            <React.Fragment key={i}>
              <div onClick={ () => handleNavigate(item)} className="px-5 flex items-center space-x-5 cursor-pointer">
                {item.icon}
                <span>{item.title}</span>
              </div>

              {i !== menu.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </div>
      </Drawer>
    </div>

  )
}


export default ProfileNavigation