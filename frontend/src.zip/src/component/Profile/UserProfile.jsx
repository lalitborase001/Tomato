import React from 'react'
import { Button } from "@mui/material";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

const UserProfile = () => {

  const handleLogout = () => {
  };

  return (
    <div className="min-h-[80vh] flex flex-col justify-center items-center text-center">     
      <div className="flex flex-col items-center justify-center">
        <AccountCircleIcon sx={{ fontSize: "9rem" }} />
        <h1 className="py-5 text-2xl font-semibold">Tomato</h1>
        <p>Email: tomato@gmail.com</p>
        <Button 
          onClick={handleLogout}
          sx={{ margin: "2rem 0rem" }}
          variant="contained"
          color="error"
        >
          Logout
        </Button>
      </div>

    </div>
  );
};

export default UserProfile